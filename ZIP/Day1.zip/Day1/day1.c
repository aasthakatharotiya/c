#include <stdio.h>

void main(){
    printf("Name: Aastha H. Katharotiya\n");
    printf("Age: 19\n");
    printf("Clg: Atmiya University\n");


    printf("---------\n");
    printf("|\t|\n");
    printf("R\t|\n");
    printf("N\t|\n");
    printf("W\t|\n");
    printf("|\t|\n");
    printf("---------\n");
    
    

    
    printf("*\n");
    printf("* *\n");
    printf("* * *\n");
    printf("* *\n");
    printf("*\n");
    
    
    
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\t  * *\t\t   *\n");
    printf("*       *     *          *\n");
    printf("*     *         *      *\n");
    printf("*   *             *  *\n");
    printf("* *\n");
    printf("*\n");
    

}